--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1
-- Dumped by pg_dump version 14.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE appiewerkendev;
--
-- Name: appiewerkendev; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE appiewerkendev WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Dutch_Netherlands.1252';


ALTER DATABASE appiewerkendev OWNER TO postgres;

\connect appiewerkendev

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: Dag; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Dag" AS ENUM (
    'MAANDAG',
    'DINSDAG',
    'WOENSDAG',
    'DONDERDAG',
    'VRIJDAG',
    'ZATERDAG',
    'ZONDAG'
);


ALTER TYPE public."Dag" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Betaalperiodes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Betaalperiodes" (
    id text NOT NULL,
    "startDatum" timestamp(3) without time zone NOT NULL,
    "eindDatum" timestamp(3) without time zone NOT NULL,
    "persoonlijkeBonus" boolean NOT NULL,
    winstuitkering boolean NOT NULL,
    slug text NOT NULL
);


ALTER TABLE public."Betaalperiodes" OWNER TO postgres;

--
-- Name: Betalingen; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Betalingen" (
    id text NOT NULL,
    "betaalPeriodeId" text NOT NULL,
    bedrag double precision NOT NULL,
    ontvangstdatum timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Betalingen" OWNER TO postgres;

--
-- Name: Shifts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Shifts" (
    id text NOT NULL,
    datum timestamp(3) without time zone NOT NULL,
    "jaarWeek" text NOT NULL,
    dag public."Dag" NOT NULL,
    "tijdslotId" text NOT NULL,
    "urenGewerkt" double precision NOT NULL,
    "urenBetaald" double precision NOT NULL,
    voltooid boolean NOT NULL,
    "winkelId" text NOT NULL,
    "uurloonId" text NOT NULL,
    "betaalperiodeId" text NOT NULL,
    feestdag boolean NOT NULL,
    werknemer text DEFAULT 'Daan'::text NOT NULL
);


ALTER TABLE public."Shifts" OWNER TO postgres;

--
-- Name: Tijdslots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Tijdslots" (
    id text NOT NULL,
    slot text NOT NULL,
    begin text NOT NULL,
    eind text NOT NULL,
    uren double precision NOT NULL
);


ALTER TABLE public."Tijdslots" OWNER TO postgres;

--
-- Name: Uurlonen; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Uurlonen" (
    id text NOT NULL,
    loon double precision NOT NULL,
    leeftijd integer NOT NULL
);


ALTER TABLE public."Uurlonen" OWNER TO postgres;

--
-- Name: Winkels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Winkels" (
    id text NOT NULL,
    "winkelNr" text NOT NULL,
    adres text NOT NULL
);


ALTER TABLE public."Winkels" OWNER TO postgres;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Data for Name: Betaalperiodes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Betaalperiodes" (id, "startDatum", "eindDatum", "persoonlijkeBonus", winstuitkering, slug) FROM stdin;
\.
COPY public."Betaalperiodes" (id, "startDatum", "eindDatum", "persoonlijkeBonus", winstuitkering, slug) FROM '$$PATH$$/3364.dat';

--
-- Data for Name: Betalingen; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Betalingen" (id, "betaalPeriodeId", bedrag, ontvangstdatum) FROM stdin;
\.
COPY public."Betalingen" (id, "betaalPeriodeId", bedrag, ontvangstdatum) FROM '$$PATH$$/3363.dat';

--
-- Data for Name: Shifts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Shifts" (id, datum, "jaarWeek", dag, "tijdslotId", "urenGewerkt", "urenBetaald", voltooid, "winkelId", "uurloonId", "betaalperiodeId", feestdag, werknemer) FROM stdin;
\.
COPY public."Shifts" (id, datum, "jaarWeek", dag, "tijdslotId", "urenGewerkt", "urenBetaald", voltooid, "winkelId", "uurloonId", "betaalperiodeId", feestdag, werknemer) FROM '$$PATH$$/3362.dat';

--
-- Data for Name: Tijdslots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Tijdslots" (id, slot, begin, eind, uren) FROM stdin;
\.
COPY public."Tijdslots" (id, slot, begin, eind, uren) FROM '$$PATH$$/3367.dat';

--
-- Data for Name: Uurlonen; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Uurlonen" (id, loon, leeftijd) FROM stdin;
\.
COPY public."Uurlonen" (id, loon, leeftijd) FROM '$$PATH$$/3365.dat';

--
-- Data for Name: Winkels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Winkels" (id, "winkelNr", adres) FROM stdin;
\.
COPY public."Winkels" (id, "winkelNr", adres) FROM '$$PATH$$/3366.dat';

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
\.
COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM '$$PATH$$/3361.dat';

--
-- Name: Betaalperiodes Betaalperiodes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Betaalperiodes"
    ADD CONSTRAINT "Betaalperiodes_pkey" PRIMARY KEY (id);


--
-- Name: Betalingen Betalingen_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Betalingen"
    ADD CONSTRAINT "Betalingen_pkey" PRIMARY KEY (id);


--
-- Name: Shifts Shifts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Shifts"
    ADD CONSTRAINT "Shifts_pkey" PRIMARY KEY (id);


--
-- Name: Tijdslots Tijdslots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Tijdslots"
    ADD CONSTRAINT "Tijdslots_pkey" PRIMARY KEY (id);


--
-- Name: Uurlonen Uurlonen_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Uurlonen"
    ADD CONSTRAINT "Uurlonen_pkey" PRIMARY KEY (id);


--
-- Name: Winkels Winkels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Winkels"
    ADD CONSTRAINT "Winkels_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Betaalperiodes_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Betaalperiodes_id_key" ON public."Betaalperiodes" USING btree (id);


--
-- Name: Betaalperiodes_slug_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Betaalperiodes_slug_key" ON public."Betaalperiodes" USING btree (slug);


--
-- Name: Betalingen_betaalPeriodeId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Betalingen_betaalPeriodeId_key" ON public."Betalingen" USING btree ("betaalPeriodeId");


--
-- Name: Betalingen_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Betalingen_id_key" ON public."Betalingen" USING btree (id);


--
-- Name: Shifts_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Shifts_id_key" ON public."Shifts" USING btree (id);


--
-- Name: Tijdslots_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Tijdslots_id_key" ON public."Tijdslots" USING btree (id);


--
-- Name: Tijdslots_slot_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Tijdslots_slot_key" ON public."Tijdslots" USING btree (slot);


--
-- Name: Uurlonen_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Uurlonen_id_key" ON public."Uurlonen" USING btree (id);


--
-- Name: Winkels_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Winkels_id_key" ON public."Winkels" USING btree (id);


--
-- Name: Winkels_winkelNr_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Winkels_winkelNr_key" ON public."Winkels" USING btree ("winkelNr");


--
-- Name: Betalingen Betalingen_betaalPeriodeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Betalingen"
    ADD CONSTRAINT "Betalingen_betaalPeriodeId_fkey" FOREIGN KEY ("betaalPeriodeId") REFERENCES public."Betaalperiodes"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Shifts Shifts_betaalperiodeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Shifts"
    ADD CONSTRAINT "Shifts_betaalperiodeId_fkey" FOREIGN KEY ("betaalperiodeId") REFERENCES public."Betaalperiodes"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Shifts Shifts_tijdslotId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Shifts"
    ADD CONSTRAINT "Shifts_tijdslotId_fkey" FOREIGN KEY ("tijdslotId") REFERENCES public."Tijdslots"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Shifts Shifts_uurloonId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Shifts"
    ADD CONSTRAINT "Shifts_uurloonId_fkey" FOREIGN KEY ("uurloonId") REFERENCES public."Uurlonen"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Shifts Shifts_winkelId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Shifts"
    ADD CONSTRAINT "Shifts_winkelId_fkey" FOREIGN KEY ("winkelId") REFERENCES public."Winkels"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

